package tw.com.asus.asusservice;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.ToggleButton;
import com.asus.ctc.irp.PModuleRemoteClient;
import com.asus.ctc.tool.DSAPI_Config;
import com.asus.ctc.tool.DSAPI_Result;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collection;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.net.URL;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import android.os.AsyncTask;
public class AsusServiceMainActivity extends AppCompatActivity {
    public String LOG_TAG = "AsusServiceMainActivity";
    public String[] welcomeList = {"Hi! Welcome to use ASUS Product Service. How can I help you?", "你好!歡迎使用華碩產品服務"};
    public String welcome = welcomeList[0];
    public final String utteranceId = "com.asus.android.asusservice";
    public String message = "";

    public TextView returnedText;
    public Button button;
    public ImageView imageview;
    public ToggleButton toggleButton;
    public ProgressBar progressBar;

    public BroadcastReceiver connectivityReceiver = null;
    public boolean connectivityState = false; //network connection flag
    public boolean internetState = false;  //internet connection flag: true - can access Internet
    public String alertMessage;
    public boolean TTSState = false; //network connection flag
    private static final String ACTIVITY_TAG="LogDemo";
    public String utteranceString[];
    PopupWindow utterancePopupWindow;
    Button utteranceButtion;
    int utterancePosition;
    long utteranceRowId;
    String appDirName = "CustomerService";
    String appUtteranceFileName = "utterance.txt";
    String[] defaultUtterance = {"華碩有什麼電子產品", "華碩有什麼電腦產品", "華碩有什麼手持產品", "華碩有什麼穿戴產品", "華碩有什麼周邊產品", "請推薦華碩的電競筆電", "請推薦華碩兩萬元以下的筆電",
            "請告訴我華碩15吋的筆電", "請推薦華碩採用Intel Core i5 CPU 的筆電"};

    AnswerCacher cacher;
    List<String> extractedUrls = new ArrayList<String>();
    List<String> Stepbystep= new ArrayList<String>();
    String summary="";
    DSAPI_Result mDSAPI_Result = null;
    TpmsHandler mTpmsHandler = null;
    final static int RoutingTtsCmd = 1550;
    final static int FinishTtsCmd = 1551;
    int stepnumber=0;
    String output_text=null;
    String output_context=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asus_service_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR); //don't rotate screen
        //getActionBar().setTitle("華碩客服系統");
        getSupportActionBar().setTitle("華碩線上商店系統");
        imageview = (ImageView) findViewById(R.id.imageView1);
        button = (Button) findViewById(R.id.button1);
        button.setOnClickListener(new SettingButtonListener());
        button.setVisibility(View.VISIBLE);
        toggleButton = (ToggleButton) findViewById(R.id.toggleButton1);
        toggleButton.setOnCheckedChangeListener(new SpeechToggleButtonListener());
        progressBar = (ProgressBar) findViewById(R.id.progressBar1);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);
        //startSLUstartSLUHello("我是華碩客服系統,請問能為您做甚麼嗎");;
        returnedText = (TextView) findViewById(R.id.textView1);
        ;
        utteranceButtion = (Button) findViewById(R.id.button2);
        utteranceButtion.setOnClickListener(new UtteranceButtonListener());
        utteranceButtion.setVisibility(View.VISIBLE);
        checkUtteranceFile();
        utteranceString = createUtteranceStringArray();
        utterancePopupWindow = createUtterancePopupWindow();
        toggleButton.setChecked(true);
        registerConnectivityReceiver();
        //checkConnectivity();
       startPerceptionModuleService();
       final String filePath = "enParticularDatatemp.txt";
        cacher = new AnswerCacher(filePath);
        mTpmsHandler = new TpmsHandler();
        //mThread.start();

    }

    class SettingButtonListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            runIrpSettingPackage();
        }
    }

    public void runIrpSettingPackage() {
        Intent intent1 = new Intent();
        intent1.setClassName("com.asus.ctc.irp", "com.asus.ctc.irp.SettingActivity");
        //Intent intent1 = getPackageManager().getLaunchIntentForPackage(
        //		"com.asus.ctc.irp");
        intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent1);
    }

    class SpeechToggleButtonListener implements CompoundButton.OnCheckedChangeListener {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
         //mPModuleRemoteClient.StopTTS();
            if (isChecked) {
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setIndeterminate(true);
                startTtsCsrSlu();
            } else {
                progressBar.setIndeterminate(false);
                progressBar.setVisibility(View.INVISIBLE);
                stopTtsCsrSlu();
            }
        }
    }

    public void registerConnectivityReceiver() {
        connectivityReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getExtras().getBoolean(ConnectivityManager.EXTRA_NO_CONNECTIVITY, Boolean.FALSE)) {
                    //no network connection
                    connectivityState = false;
                    internetState = false;
                    showAlertDialog("No Network Connetion");
                } else {
                    connectivityState = true;
                    //check if it can access internet
                    ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                    internetState = (networkInfo != null) && networkInfo.isConnectedOrConnecting();
                    if (!internetState) {
                        showAlertDialog("Has network connection but CAN NOT access Internet");
                    }
                }
            }
        };
        registerReceiver(connectivityReceiver, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
    }

    public void checkConnectivity() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo == null) { //no netwwork connection
            connectivityState = false;
            internetState = false;
            showAlertDialog("No Network Connetion");
        } else {
            connectivityState = true; //has network connection
            internetState = netInfo.isConnectedOrConnecting();
            if (internetState == false) { //no internet access
                showAlertDialog("Has network connection but CAN NOT access Internet");
            }
        }
    }


    public void showAlertDialog(String message) {
        alertMessage = message;
        AsusServiceMainActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                new AlertDialog.Builder(AsusServiceMainActivity.this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setIconAttribute(android.R.attr.alertDialogIcon)
                        .setTitle("NOTIFICATION")
                        .setMessage(alertMessage)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
    }

    PModuleRemoteClient mPModuleRemoteClient = null;
    boolean State_btnStartTtsCsrSlu = false;
    JSONObject StateIntentions = null;
    String CsrTypeStr = "CSR_TYPE_Google";
    String LanguageTypeStr = "CSR_TYPE_Google";
    String sentenceStr = "Welcome to  ASUS Customer Service";

    void startPerceptionModuleService() {
        if (mPModuleRemoteClient == null) {
            mPModuleRemoteClient = new PModuleRemoteClient(this, new PModuleRemoteClient.PModuleListener() {
                @Override
                public void onFinishInitPModule() {
                    // TODO Auto-generated method stub
                    //mTpmsHandler.sendMessage(mTpmsHandler.obtainMessage(MSG_onFinishInitPModule));
                    //message += "onFinishInitPModule " + "\n";
                    //returnedText.setText(message);
                    startTtsCsrSlu();
                }

                @Override
                public void onFinishTTS(String eventAck, String sentence, String error_code) {
                    // TODO Auto-generated method stub
//                            //mTpmsHandler.sendMessage(mTpmsHandler .obtainMessage(MSG_onFinishTTS, eventAck));
                    //message += "onFinishTTS [" + sentence + "]; \"error_code\"=\"" + error_code + "\"\n";
                    Log.v(AsusServiceMainActivity.ACTIVITY_TAG, message);
                   // returnedText.setText("hello1");
//                    if (!Stepbystep.isEmpty()) {
//                        startTTS(Stepbystep.get(1));
//                 //       Stepbystep.remove(1);
//                    }
//                    if (!Stepbystep.isEmpty())
//                            startTTS(Stepbystep.get(1));
//                    Stepbystep.clear();
//                    TTSState = true; //network connection flag
//
//                    JSONArray array = null;
//                    try {
//                        array = new JSONArray(sentence);
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
//
//                    for (int i = 0; i < array.length(); i++) {
//                        JSONObject jsonObj = null;
//                        try {
//                            jsonObj = array.getJSONObject(i);
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                        org.json.simple.JSONObject result = new org.json.simple.JSONObject();
//                        if (jsonObj.has("Step"))
//                            try {
//                                String data = jsonObj.getString("tts");
//                                returnedText.setText(data);
//                            } catch (JSONException e) {
//                                e.printStackTrace();
//
//                            }
////                            toggleButton.setChecked(false);
//
//                        //  mPModuleRemoteClient.StopTTS();
//                    }
                }
                @Override
                public void onEvent_VAD_STATUS(JSONObject Result, String eventAck) {
                    // TODO Auto-generated method stub
                    //mTpmsHandler.sendMessage(mTpmsHandler.obtainMessage(MSG_onEventTrigger,  Result.toString()));
                    //DSAPI_Result mDSAPI_Result = new DSAPI_Result(Result.toString());
//                     message += "onEvent_VAD_STATUS ["  + Result.toString() + "] " + "\n";
//                    returnedText.setText(message);
                }

                @Override
                public void onEVENT_USER_UTTERANCE(JSONObject Result, String eventAck) {
                    // TODO Auto-generated method stub
                            /*
							 * try { mTpmsHandler.sendMessage(mTpmsHandler
							 * .obtainMessage(MSG_onCsrResult, Result
							 * .getString("userUtterances"))); } catch
							 * (JSONException e) {
							 */
                    // TODO Auto-generated catch block
                    DSAPI_Result mDSAPI_Result = new DSAPI_Result(Result.toString());
                    // speech_data_path = mDSAPI_Result.event_user_utterance.speech_data_path();
                    //mTpmsHandler.sendMessage(mTpmsHandler.obtainMessage(MSG_onCsrResult, mDSAPI_Result.event_user_utterance.toJson().toString()));

                    // get keyword trigger
                    //if (mDSAPI_Result.event_user_utterance.engineType() == DSAPI_Config.CSR_TYPE_VoiceTrigger
                    //        && mDSAPI_Result.event_user_utterance.slu_query_index() != 0) {
                    //         enableButton(false);
                    //}

                    message += "onEvent_USER_UTTERANCE [" + mDSAPI_Result.event_user_utterance.toJson().toString() + "] " + "\n";
                    if (!message.contains("timeout")) {
//                       returnedText.setText(message);
                       startTtsCsrSlu();
                        Log.v(AsusServiceMainActivity.ACTIVITY_TAG, message);
                    }
                }


                @Override
                public void onEVENT_SLU_QUERY(JSONObject Result, String eventAck) {
                    // TODO Auto-generated method stub
                    //DSAPI_Result mDSAPI_Result = new DSAPI_Result(Result.toString());
                    //String voconUtterance=mDSAPI_Result.event_slu_query.user_utterance_vocon();
                    //mTpmsHandler.sendMessage(mTpmsHandler.obtainMessage(MSG_onSluResult, Result.toString()));\
                    org.json.simple.JSONObject keyconcepts = new org.json.simple.JSONObject();
                    String result = null;
                    DSAPI_Result mDSAPI_Result = new DSAPI_Result(Result.toString());
                    String error_code = mDSAPI_Result.event_slu_query.error_code();
                    imageview.setImageResource(R.drawable.asuslogonew);
                    if (Result.toString() != null) {
                        message += "onEvent_SLU_QUERY [" + Result.toString() + "; \"error_code\"=\"" + error_code + "\"] " + "\n";
                        if (!message.contains("timeout")) {
                            if (Result.toString().contains("Domain\":\"11355")) {
                                keyconcepts = parseSLUQuery("[" + Result.toString() + "]");
                                result = cacher.lookup(keyconcepts);
                                returnedText.setText(result);
                                //stopTtsCsrSlu();
                                //result = removehttplink(result);
                                //toggleButton.setChecked(false);
                                progressBar.setVisibility(View.VISIBLE);
                                progressBar.setIndeterminate(true);
                                if (!output_context.isEmpty()&&!output_text.isEmpty())
                                    ContextGeneration(output_context,output_text);
                                if(result!=null)
                                GenerateSteps(result);
                                //returnedText.setText(summary);

                                stepnumber=0;
                                Stepbystep.clear();
                            }
                        } else {
                            message += "onEvent_SLU_QUERY [" + "\"error_code\"=\"" + error_code + "\"] " + "\n";
                            returnedText.setText(message);

                        }

                            returnedText.setText(Result.toString());

                        // startTTS("請問您還有問題嗎");
                        // toggleButton.setChecked(true);
                        //startTtsCsrSlu();
                    }
                }
                private Handler mHandler = new Handler(){
                    public void handleMessage(Message msg){
                        switch(msg.what){
                            case 0:
                                Log.e("HandlerThreadID", Long.toString(Thread.currentThread().getId()));
                                Log.e("HandlerThreadName", Thread.currentThread().getName());
                                break;
                        }
                    }
                };

                private Thread mThread = new Thread(new Runnable() {
                    public void run() {
                        Log.e("ThreadID", Long.toString(Thread.currentThread().getId()));
                        Log.e("ThreadName", Thread.currentThread().getName());
                        Message msg = new Message();
                        msg.what = 0;
                        mHandler.sendMessage(msg);

                    }
                });


                @Override
                public void onAskBackProcess(JSONObject arg0, String arg1) {
                    // TODO Auto-generated method stub
                    //message += "onAskBackProcess " + "\n";
                    //returnedText.setText(message);
                }
            });
        }
    }

    class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();

        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                // Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            super.onPostExecute(result);

            bmImage.setImageBitmap(result);
        }
    }


    public   void GenerateSteps(String result) {

        String data = "";
        Scanner scanner = new Scanner(result);
       // steps=0;
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.contains("http")) {
                extractedUrls = extractUrls(result);
                continue;

            }
            else if (line.contains("Step")) {
                Stepbystep.add(line+"\n");
                stepnumber++;
                continue;

            }
            else
                summary += line+"\n";
            // process the line
        }

        scanner.close();
        if( summary=="") {
            for (int i=0;i < Stepbystep.size();i++)
            {
                summary+=Stepbystep.get(i);

            }
        }

    }
    public   void NextStep(int i) {
       // returnedText.setText("");
       // returnedText.setText("步驟說明");
      //  new DownloadImageTask(imageview).execute(extractedUrls.get(i));
    }

    public   void ContextGeneration(String output_context, String output_text) {
        //if output_context.contains()
        if (!output_text.isEmpty()) {
            startTTS(output_text);
            startTtsCsrSlu();
            //  if (output_context.contains("ConfirmNo")){ ;//沒有 離開 我要問下一個問題
            //    startTTS("byebye:");
            //  }
              if (output_context.contains("YesAction")){//好的 是的
                  NextStep(++stepnumber);
                  startTTS(output_text);
                  //returnedText.setText("步驟說明");
                  //startTtsCsrSlu("還想看下一個步驟嗎");
                   Thread thread;
                  thread=  new Thread(){
                      @Override
                      public void run(){
                          try {
                              synchronized(this){
                                  wait(3000);
                                  startTtsCsrSlu("還想看下一個步驟嗎");
                              }
                          }
                          catch(InterruptedException ex){
                          }

                          // TODO
                      }
                  };

                  thread.start();

             }
            if (output_context.contains("NoAction")){//好的 是的
                //NextStep(++stepnumber);
                startTTS(output_text);
                returnedText.setText("");
                startTtsCsrSlu();
            }
        }
    }
    /**
     * Returns a list with all links contained in the input
     */
    public static List<String> extractUrls(String text) {
        List<String> containedUrls = new ArrayList<String>();
        String urlRegex = "((https?|ftp|gopher|telnet|file):((//)|(\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)";
        Pattern pattern = Pattern.compile(urlRegex, Pattern.CASE_INSENSITIVE);
        Matcher urlMatcher = pattern.matcher(text);

        while (urlMatcher.find()) {
            containedUrls.add(text.substring(urlMatcher.start(0),
                    urlMatcher.end(0)));
        }

        return containedUrls;
    }

    /* Comments
                          Correct speech errors in the ErrorCorrection
                         3 types of errors can be handled:
                         	Nointent
                         	Multiintents
                          	One intent but lack at least one parameter

*/
    public void ErrorCorrection(String intetionID) {
        //fasttext
    }

    /* Comments
                 Get key concepts of intents
                  */
    public org.json.simple.JSONObject parseSLUQuery(String message) {
        // Creating JSON Parser instance
        //  message = "[{\"Domain\":\"11337\",\"SystemObject\":\"windows7\",\"originalSentence\":\"如何還原windows\",\"output_context\":\"[ASK_HOWTOUPGRADE_SYSTEM]\",\"Intentionid\":\"plan4.ask.HowToUpgrade.System\",\"HowToUpgradeSystemValue\":\"restore\"}]";
        org.json.simple.JSONObject result = new org.json.simple.JSONObject();
        try {
//                    String data=message.substring(message.indexOf("onEvent_SLU_QUERY")+17);
//                if( data.contains("Domain")) {
            JSONArray array = new JSONArray(message);

            for (int i = 0; i < array.length(); i++) {
                JSONObject jsonObj = array.getJSONObject(i);
                if (jsonObj.has("HowToKnow")&&!jsonObj.getString("HowToKnow").isEmpty())
                    result.put("HowToKnow", jsonObj.getString("HowToKnow"));
                if (jsonObj.has("Product")&&!jsonObj.getString("Product").isEmpty())
                    result.put("Product", jsonObj.getString("Product"));
                if (jsonObj.has("HowToUpgradeSystemValue")&&!jsonObj.getString("HowToUpgradeSystemValue").isEmpty())
                    result.put("HowToUpgradeSystemValue", jsonObj.getString("HowToUpgradeSystemValue"));
                if (jsonObj.has("HowToUpgradeApplicationValue")&&!jsonObj.getString("HowToUpgradeApplicationValue").isEmpty())
                    result.put("HowToUpgradeApplicationValue", jsonObj.getString("HowToUpgradeApplicationValue"));
                if (jsonObj.has("SystemObject")&&!jsonObj.getString("SystemObject").isEmpty())
                    result.put("SystemObject", jsonObj.getString("SystemObject"));
                if (jsonObj.has("ApplicationObject")&& !jsonObj.getString("ApplicationObject").isEmpty())
                    result.put("ApplicationObject", jsonObj.getString("ApplicationObject"));
                if (jsonObj.has("HowToUseApplicationValue")&&!jsonObj.getString("HowToUseApplicationValue").isEmpty())
                    result.put("HowToUseApplicationValue", jsonObj.getString("HowToUseApplicationValue"));
                if (jsonObj.has("KeyPartSystemObject")&&!jsonObj.getString("KeyPartSystemObject").isEmpty())
                    result.put("KeyPartSystemObject", jsonObj.getString("KeyPartSystemObject"));
                if (jsonObj.has("AccessorySystemObject")&&!jsonObj.getString("AccessorySystemObject").isEmpty())
                    result.put("AccessorySystemObject", jsonObj.getString("AccessorySystemObject"));
                //      if (jsonObj.getString("output_context") != null)
//                            result.put("output_context", jsonObj.getString("output_context"));
                if (jsonObj.has("output_text"))
                    output_text=jsonObj.getString("output_text");
                if (jsonObj.has("output_context"))
                    output_context=jsonObj.getString("output_text");
                if (jsonObj.has("HowToUseScenarioChargingValue")&&!jsonObj.getString("HowToUseScenarioChargingValue").isEmpty())
                    result.put("HowToUseScenarioChargingValue", jsonObj.getString("HowToUseScenarioChargingValue"));
                if (jsonObj.has("HowToUseScenarioAnsweringphoneValue")&&!jsonObj.getString("HowToUseScenarioAnsweringphoneValue").isEmpty())
                    result.put("HowToUseScenarioAnsweringphoneValue", jsonObj.getString("HowToUseScenarioAnsweringphoneValue"));
                if (jsonObj.has("HowToUseAccessoryApplicationValue")&&!jsonObj.getString("HowToUseAccessoryApplicationValue").isEmpty())
                    result.put("HowToUseAccessoryApplicationValue", jsonObj.getString("HowToUseAccessoryApplicationValue"));
                if (jsonObj.has("HowToUseKeypartApplicationValue")&&!jsonObj.getString("HowToUseKeypartApplicationValue").isEmpty())
                    result.put("HowToUseKeypartApplicationValue", jsonObj.getString("HowToUseKeypartApplicationValue"));
                if (jsonObj.has("HowToUseKeypartSystemValue")&&!jsonObj.getString("HowToUseKeypartSystemValue").isEmpty())
                    result.put("HowToUseKeypartSystemValue", jsonObj.getString("HowToUseKeypartSystemValue"));
                if (jsonObj.has("HowToUseSystemValue")&&!jsonObj.getString("HowToUseSystemValue").isEmpty())
                    result.put("HowToUseSystemValue", jsonObj.getString("HowToUseSystemValue"));

                if (jsonObj.has("HowToUseApplicationValue")&&!jsonObj.getString("HowToUseApplicationValue").isEmpty())
                    result.put("HowToUseApplicationValue", jsonObj.getString("HowToUseApplicationValue"));
                if (jsonObj.has("AbnormalSystemValue")&&!jsonObj.getString("AbnormalSystemValue").isEmpty())
                        result.put("AbnormalSystemValue", jsonObj.getString("AbnormalSystemValue"));
                if (jsonObj.has(" AccessorySystemObject")&&!jsonObj.getString(" AccessorySystemObject").isEmpty())
                    result.put(" AccessorySystemObject", jsonObj.getString(" AccessorySystemObject"));
                if (jsonObj.has("AbnormalAccessorySystemValue")&&!jsonObj.getString("AbnormalAccessorySystemValue").isEmpty())
                    result.put("AbnormalAccessorySystemValue", jsonObj.getString("AbnormalAccessorySystemValue"));
                if (jsonObj.has("AbnormalAccessoryApplicationValue")&&!jsonObj.getString("AbnormalAccessoryApplicationValue").isEmpty())
                    result.put("AbnormalAccessoryApplicationValue", jsonObj.getString("AbnormalAccessoryApplicationValue"));
                if (jsonObj.has("AbnormalKeyPartSystemValue")&&!jsonObj.getString("AbnormalKeyPartSystemValue").isEmpty())
                    result.put("AbnormalKeyPartSystemValue", jsonObj.getString("AbnormalKeyPartSystemValue"));
                if (jsonObj.has("AbnormalKeyPartApplicationValue")&&!jsonObj.getString("AbnormalKeyPartApplicationValue").isEmpty())
                    result.put("AbnormalKeyPartApplicationValue", jsonObj.getString("AbnormalKeyPartApplicationValue"));
                if (jsonObj.has("AbnormalApplicationValue")&&!jsonObj.getString("AbnormalApplicationValue").isEmpty())
                    result.put("AbnormalApplicationValue", jsonObj.getString("AbnormalApplicationValue"));
                if (jsonObj.has("AbnormalScenarioAnsweringPhoneValue")&&!jsonObj.getString("AbnormalScenarioAnsweringPhoneValue").isEmpty())
                    result.put("AbnormalScenarioAnsweringPhoneValue", jsonObj.getString("AbnormalScenarioAnsweringPhoneValue"));
                if (jsonObj.has("AbnormalScenarioTakingPhotoValue")&&!jsonObj.getString("AbnormalScenarioTakingPhotoValue").isEmpty())
                    result.put("AbnormalScenarioTakingPhotoValue", jsonObj.getString("AbnormalScenarioTakingPhotoValue"));
                if (jsonObj.has("AbnormalScenarioChargingValue")&&!jsonObj.getString("AbnormalScenarioChargingValue").isEmpty())
                    result.put("AbnormalScenarioChargingValue", jsonObj.getString("AbnormalScenarioChargingValue"));

                if (jsonObj.has("WhatIsSystemValue")&&!jsonObj.getString("WhatIsSystemValue").isEmpty())
                    result.put("WhatIsSystemValue", jsonObj.getString("WhatIsSystemValue"));
                if (jsonObj.has("WhatIs")&&!jsonObj.getString("WhatIs").isEmpty())
                    result.put("WhatIs", jsonObj.getString("WhatIs"));

                if (jsonObj.has("WhatIsApplicationValue")&&!jsonObj.getString("WhatIsApplicationValue").isEmpty())
                    result.put("WhatIsApplicationValue", jsonObj.getString("WhatIsApplicationValue"));
                if (jsonObj.has("WhatIsKeypartSystemValue")&&!jsonObj.getString("WhatIsKeypartSystemValue").isEmpty())
                    result.put("WhatIsKeypartSystemValue", jsonObj.getString("WhatIsKeypartSystemValue"));
                if (jsonObj.has("WhatIsKeypartSystemValue")&&!jsonObj.getString("WhatIsKeypartSystemValue").isEmpty())
                    result.put("WhatIsKeypartSystemValue", jsonObj.getString("WhatIsKeypartSystemValue"));
                if (jsonObj.has("WhatIsKeypartApplicationValue")&&!jsonObj.getString("WhatIsKeypartApplicationValue").isEmpty())
                    result.put("WhatIsKeypartApplicationValue", jsonObj.getString("WhatIsKeypartApplicationValue"));
                if (jsonObj.has("WhatIsAcessorySystemValue")&&!jsonObj.getString("WhatIsAcessorySystemValue").isEmpty())
                    result.put("WhatIsAcessorySystemValue", jsonObj.getString("WhatIsAcessorySystemValue"));
                if (jsonObj.has("WhatIsAcessoryApplicationValue")&&!jsonObj.getString("\"WhatIsAcessoryApplicationValue\"").isEmpty())
                    result.put("WhatIsAcessoryApplicationValue", jsonObj.getString("WhatIsAcessoryApplicationValue"));
                if (jsonObj.has("MaintenanceGeneralValue")&&!jsonObj.getString("MaintenanceGeneralValue").isEmpty())
                    result.put("MaintenanceGeneralValue", jsonObj.getString("MaintenanceGeneralValue"));
                if (jsonObj.has("HowToCleanKeyPartSystemValue")&&!jsonObj.getString("HowToCleanKeyPartSystemValue").isEmpty())
                    result.put("HowToCleanKeyPartSystemValue", jsonObj.getString("HowToCleanKeyPartSystemValue"));
                if (jsonObj.has("WhereIsKeyPartSystemObjectValue")&&!jsonObj.getString("WhereIsKeyPartSystemObjectValue").isEmpty())
                    result.put("WhereIsKeyPartSystemObjectValue", jsonObj.getString("WhereIsKeyPartSystemObjectValue"));
                if (jsonObj.has("MaintenanceObject")&&!jsonObj.getString("MaintenanceObject").isEmpty())
                    result.put("MaintenanceObject", jsonObj.getString("MaintenanceObject"));
                if (jsonObj.has("MaintenanceObject")&&!jsonObj.getString("MaintenanceObject").isEmpty())
                    result.put("MaintenanceObject", jsonObj.getString("MaintenanceObject"));
                if (jsonObj.has("ScenarioObject")&&!jsonObj.getString("ScenarioObject").isEmpty())
                    result.put("ScenarioObject", jsonObj.getString("ScenarioObject"));
//                if (jsonObj.has("YesNoSystemValue"))
//                    result.put("YesNoSystemValue", jsonObj.getString("YesNoSystemValue"));
//                if (jsonObj.has("YesNoApplicationValue"))
//                    result.put("YesNoApplicationValue", jsonObj.getString("YesNoApplicationValue"));
//                if (jsonObj.has("YesNoKeypartSystemValue"))
//                    result.put("YesNoKeypartSystemValue", jsonObj.getString("YesNoKeypartSystemValue"));
//                if (jsonObj.has("YesNoKeypartApplicationValue"))
//                    result.put("YesNoKeypartApplicationValue", jsonObj.getString("YesNoKeypartApplicationValue"));
//                if (jsonObj.has("YesNoAcessorySystemValue"))
//                    result.put("YesNoAcessorySystemValue", jsonObj.getString("YesNoAcessorySystemValue"));
//                if (jsonObj.has("YesNoAcessoryApplicationValue"))
//                    result.put("YesNoAcessoryApplicationValue", jsonObj.getString("YesNoAcessoryApplicationValue"));
//                if (jsonObj.has("YesNoScenarioChargingValue"))
//                    result.put("YesNoScenarioChargingValue", jsonObj.getString("YesNoScenarioChargingValue"));


            }
//                }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return result;
    }

    public void startTtsCsrSlu() {

        if (mPModuleRemoteClient != null) {
           // mPModuleRemoteClient.StopTTS();
            if (StateIntentions == null) StateIntentions = new JSONObject();
            DSAPI_Config dsapi_config = new DSAPI_Config();
            dsapi_config.tts.set_tts(sentenceStr);
            dsapi_config.csr.set_timeout(10000);
            dsapi_config.csr.set_showCsrWindows(false);
            // {\"START_SHOT\",\"STOP_SHOT\"}"
            dsapi_config.csr.set_voiceEngineType(CsrTypeStr);
            //dsapi_config.csr.set_languageType(LanguageTypeStr);
            dsapi_config.slu.set_maxAckBackNum(3);
            //	dsapi_config.slu.set_StateListenContext("117", "reminder_message_ok,remoinder_message_delay,reminder_todo_reach,reminder_prompt,back_home");
            dsapi_config.slu.set_StateIntentions(StateIntentions);
            //	dsapi_config.slu.set_StateListenContext("117", "reminder_todo_reach,reminder_todo_partially_completed,reminder_todo_partially_not_completed");
            //dsapi_config.set_OnStageConfig();
            message += sentenceStr + "\n";
            // if (!sentenceStr.isEmpty())
//            returnedText.setText(message);
            String status = mPModuleRemoteClient.startTtsCsrSlu(dsapi_config, new PModuleRemoteClient.SluListener() {
                @Override
                public void onFinishSlu(JSONObject Result) {
                    // TODO Auto-generated method stub
//                   message += "onFinishSlu\n";
//                    returnedText.setText(message);
                }

                @Override
                public void onAskBackProcess(JSONObject arg0) {
                    // TODO Auto-generated method stub
                   // message += "onAskBackProcess2 " + "\n";
                   // returnedText.setText(message);
                }
            });

            sentenceStr = "";
            StateIntentions = null;
            // tvShowInfo.setText("btnStartTtsCsrSlu");
            State_btnStartTtsCsrSlu = true;
            //message += "startTtsCsrSlu status=" + status + "\n";
            //returnedText.setText(message);
        }
    }

    public void startTtsCsrSlu(String sentenceStr) {
        message = "";
        if (!extractedUrls.isEmpty() )
            extractedUrls.clear();
        if(!Stepbystep.isEmpty()) {
            Stepbystep.clear();
        }
        if (TTSState==true)
            mPModuleRemoteClient.StopTTS();
        if (!extractedUrls.isEmpty() )
            extractedUrls.clear();
        if(!Stepbystep.isEmpty()) {
            Stepbystep.clear();
        }

        if (mPModuleRemoteClient != null) {
            // mPModuleRemoteClient.StopTTS();
            if (StateIntentions == null) StateIntentions = new JSONObject();
            DSAPI_Config dsapi_config = new DSAPI_Config();
            dsapi_config.tts.set_tts(sentenceStr);
            dsapi_config.csr.set_timeout(10000);
            dsapi_config.csr.set_showCsrWindows(false);
            // {\"START_SHOT\",\"STOP_SHOT\"}"
            dsapi_config.csr.set_voiceEngineType(CsrTypeStr);
            //dsapi_config.csr.set_languageType(LanguageTypeStr);
            dsapi_config.slu.set_maxAckBackNum(3);
            //	dsapi_config.slu.set_StateListenContext("117", "reminder_message_ok,remoinder_message_delay,reminder_todo_reach,reminder_prompt,back_home");
            dsapi_config.slu.set_StateIntentions(StateIntentions);
            //	dsapi_config.slu.set_StateListenContext("117", "reminder_todo_reach,reminder_todo_partially_completed,reminder_todo_partially_not_completed");
            //dsapi_config.set_OnStageConfig();
            message += sentenceStr + "\n";
            // if (!sentenceStr.isEmpty())
//            returnedText.setText(message);
            String status = mPModuleRemoteClient.startTtsCsrSlu(dsapi_config, new PModuleRemoteClient.SluListener() {
                @Override
                public void onFinishSlu(JSONObject Result) {
                    // TODO Auto-generated method stub
//                   message += "onFinishSlu\n";
//                    returnedText.setText(message);
                }

                @Override
                public void onAskBackProcess(JSONObject arg0) {
                    // TODO Auto-generated method stub
                    message += "onAskBackProcess2 " + "\n";
                  //  returnedText.setText(message);
                }
            });

            sentenceStr = "";
            StateIntentions = null;
            // tvShowInfo.setText("btnStartTtsCsrSlu");
            State_btnStartTtsCsrSlu = true;
            //message += "startTtsCsrSlu status=" + status + "\n";
            //returnedText.setText(message);
        }
    }

    public void stopTtsCsrSlu() {
        mPModuleRemoteClient.stopTtsCsrSlu();
        State_btnStartTtsCsrSlu = false;
    }

    public void startSLU() {
        if (mPModuleRemoteClient != null) {

            if (StateIntentions == null) StateIntentions = new JSONObject();
            DSAPI_Config dsapi_config = new DSAPI_Config();
            JSONArray querySentqnce = new JSONArray();
            querySentqnce.put(utteranceString[utterancePosition]);
            //querySentqnce.put("事件名稱改成看電影");
            dsapi_config.slu.set_close_current_app();
            dsapi_config.slu.set_querySentance(querySentqnce);
            //	dsapi_config.slu.set_StateJump2Intention("189", "findpersonactive.run");
            //	dsapi_config.slu.set_StateJump2Intention("184", "START_OUTPATIENTS");
            //	dsapi_config.slu.set_StateListenContext("188", "SCAN_ENOUGH_POWER");
            //reminder_message_ok,remoinder_message_delay,reminder_todo_reach,reminder_prompt,back_home
            //dsapi_config.slu.set_StateListenContext("117", "reminder_message_ok,remoinder_message_delay,reminder_todo_reach,reminder_prompt,back_home");
            dsapi_config.slu.set_StateListenContext("1212", "reminder_return,reminder_prompt,delete_action,confirm,finish,back_home,add_modify,add_modifytime");
            dsapi_config.slu.set_StateIntentions(StateIntentions);
            dsapi_config.slu.set_maxAckBackNum(3);
            //	tvShowInfo.setText("MSG_btnStartSLU StateIntentions="+(dsapi_config.slu.StateIntentions()).toString()+" Utterance="+dsapi_config.slu.querySentance().toString());
            mPModuleRemoteClient.ConfigAutoTriggerCsrSlu(dsapi_config);
//            message += "startSLU\n";
            returnedText.setText(utteranceString[utterancePosition]);
            String status = mPModuleRemoteClient.SLU_Query(dsapi_config,
                    new PModuleRemoteClient.SluListener() {
                        @Override
                        public void onFinishSlu(JSONObject Result) {
//                            DSAPI_Result mDSAPI_Result = new DSAPI_Result(Result.toString());
//                            JSONObject app_semantic = mDSAPI_Result.event_slu_query.app_semantic();
//                            String output_text="";
//                            if(app_semantic!=null){
//                                try {
//                                    output_text=app_semantic.getString("output_text");
//                                    message += "onFinishSLU\n";
//                                    returnedText.setText(message);
//                                } catch (JSONException e) {
//                                    // TODO Auto-generated catch block
//                                    e.printStackTrace();
//                                }
//                            }
                        }

                        @Override
                        public void onAskBackProcess(JSONObject arg0) {
                            // TODO Auto-generated method stub

                        }
                    });
            StateIntentions = null;
            //message += "SLU_Quey status=" + status + "\n";
            //returnedText.setText(message);
        }
    }


    public void startTTS(String utteranceString) {
        if (mPModuleRemoteClient != null) {
            DSAPI_Config dsapi_config = new DSAPI_Config();
            dsapi_config.tts.set_tts(utteranceString);

            JSONObject config = new JSONObject();
            try {

                config.put("SetSpeakerID", 1); // 銝剜��
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            dsapi_config.tts.set_ConfigParameter(config);
            mPModuleRemoteClient.startTTS(dsapi_config,
                    new PModuleRemoteClient.TtsListener() {


                        @Override
                        public void onFinishTts(String sentence, String error_code) {
                            // TODO Auto-generated method stub
                         //   message += "onFinishTTS [" + sentence +"]; \"error_code\"=\"" + error_code + "\"\n";
                            Log.v(AsusServiceMainActivity.ACTIVITY_TAG, message);
                          //  if (!Stepbystep.isEmpty())
                           //     startTTS(Stepbystep.get(1));
                      //      startTTS(Stepbystep.get(1));
//                           // for (String url : extractedUrls) {
//                                //returnedText.setText(url);
//                                returnedText.setText("xxx1x");
                            try {
                                String url="https://www.asus.com/zentalk/tw/data/attachment/forum/201610/31/085136d591ctdmcxggca1r.jpg.thumb.jpg";
//                                returnedText.setText("2");
                                URL source = new URL(url);
                                //new DownloadImageTask(imageview).execute(url);
                                //SystemClock.sleep(3000);
                               // returnedText.setText("");
                               // imageview.setVisibility(View.INVISIBLE);
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }

                        }

                    });
        }

    }
    public void checkUtteranceFile() {
        String state = Environment.getExternalStorageState();
        if (!Environment.MEDIA_MOUNTED.equals(state)) {
            showAlertDialog("no external storage");
        }
        File dirFile = new File(Environment.getExternalStorageDirectory(), appDirName);
        if (!dirFile.exists()) {
            dirFile.mkdir();
        }
        dirFile.setReadable(true);
        dirFile.setWritable(true);
        File utrFile = new File(dirFile, appUtteranceFileName);
        if (!utrFile.exists()) {
            //create a default
            try {
                if (utrFile.createNewFile()) {
                    //add utterance to it.
                    utrFile.setReadable(true);
                    utrFile.setWritable(true);
                    BufferedWriter writer = new BufferedWriter(new FileWriter(utrFile));
                    for (int i = 0; i < defaultUtterance.length; i++) {
                        writer.write(defaultUtterance[i]);
                        writer.newLine();
                    }
                    writer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public String[] createUtteranceStringArray() {
        String[] stringArray;
        List<String> stringList = new ArrayList<String>();
        String inputLine;

        File dirFile = new File(Environment.getExternalStorageDirectory(), appDirName);
        if (dirFile.exists()) {
            File utrFile = new File(dirFile, appUtteranceFileName);
            if (utrFile.exists()) {
                try {
                    //add utterance to it.
                    BufferedReader bufReader = new BufferedReader(new FileReader(utrFile));
                    while ((inputLine = bufReader.readLine()) != null) {
                        if (inputLine.length() != 0) {
                            stringList.add(inputLine);
                        }
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        stringArray = new String[stringList.size()];
        stringList.toArray(stringArray);
        return stringArray;
    }

    public PopupWindow createUtterancePopupWindow() {
        PopupWindow popupWindow1 = new PopupWindow(this);
        ListView listView1 = new ListView(this);
        listView1.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, utteranceString));
        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                utterancePosition = position;
                utteranceRowId = id;
                utterancePopupWindow.dismiss();
                message = "Utterance: " + utteranceString[position] + "\n";
                returnedText.setText(message);
                progressBar.setVisibility(View.VISIBLE);  //kimtest
                progressBar.setIndeterminate(true);         //kimtest
                startSLU();
            }
        });
        popupWindow1.setFocusable(true);
        popupWindow1.setWidth(WindowManager.LayoutParams.MATCH_PARENT);
        popupWindow1.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        popupWindow1.setContentView(listView1);
        return popupWindow1;
    }

    class UtteranceButtonListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            utterancePopupWindow.showAsDropDown(v);
        }
    }

    public void TtsCsrSlu(String sentenceStr) {
        message = "";
        if (!extractedUrls.isEmpty() )
            extractedUrls.clear();
        if(!Stepbystep.isEmpty()) {
            Stepbystep.clear();
        }
        if (TTSState==true)
            mPModuleRemoteClient.StopTTS();
        if (!extractedUrls.isEmpty() )
            extractedUrls.clear();
        if(!Stepbystep.isEmpty()) {
            Stepbystep.clear();
        }

        if (mPModuleRemoteClient != null) {
            // mPModuleRemoteClient.StopTTS();
            if (StateIntentions == null) StateIntentions = new JSONObject();
            DSAPI_Config dsapi_config = new DSAPI_Config();
            dsapi_config.tts.set_tts(sentenceStr);
            dsapi_config.csr.set_timeout(10000);
            dsapi_config.csr.set_showCsrWindows(false);
            // {\"START_SHOT\",\"STOP_SHOT\"}"
            dsapi_config.csr.set_voiceEngineType(CsrTypeStr);
            //dsapi_config.csr.set_languageType(LanguageTypeStr);
            dsapi_config.slu.set_maxAckBackNum(3);
            //	dsapi_config.slu.set_StateListenContext("117", "reminder_message_ok,remoinder_message_delay,reminder_todo_reach,reminder_prompt,back_home");
            dsapi_config.slu.set_StateIntentions(StateIntentions);
            //	dsapi_config.slu.set_StateListenContext("117", "reminder_todo_reach,reminder_todo_partially_completed,reminder_todo_partially_not_completed");
            //dsapi_config.set_OnStageConfig();
            message += sentenceStr + "\n";
            // if (!sentenceStr.isEmpty())
//            returnedText.setText(message);
            String status = mPModuleRemoteClient.startTtsCsrSlu(dsapi_config, new PModuleRemoteClient.SluListener() {
                @Override
                public void onFinishSlu(JSONObject Result) {
//                    if (!Stepbystep.isEmpty()) {
//                        startTTS(Stepbystep.get(1));
//                        //       Stepbystep.remove(1);
//                    }
                }

                @Override
                public void onAskBackProcess(JSONObject arg0) {
                    // TODO Auto-generated method stub
                   // message += "onAskBackProcess2 " + "\n";
                    returnedText.setText(message);
                }
            });

            sentenceStr = "";
            StateIntentions = null;
            // tvShowInfo.setText("btnStartTtsCsrSlu");
            State_btnStartTtsCsrSlu = true;
            //message += "startTtsCsrSlu status=" + status + "\n";
            //returnedText.setText(message);
        }
    }

    private Handler mHandler = new Handler(){
        public void handleMessage(Message msg){
            switch(msg.what){
                case 0:
                    Log.e("HandlerThreadID", Long.toString(Thread.currentThread().getId()));
                    Log.e("HandlerThreadName", Thread.currentThread().getName());
                    break;
            }
        }
    };



    public class TpmsHandler extends Handler {

        @SuppressWarnings("null")
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case FinishTtsCmd:
                    String MsgString = (String)msg.obj;
                    for (String url : extractedUrls) {
                        if(!extractedUrls.isEmpty()) {
                            new DownloadImageTask(imageview).execute(extractedUrls.get(Integer.parseInt(MsgString)));
                            extractedUrls.remove(Integer.parseInt(MsgString));
                        }

                    }
                    break;

                case RoutingTtsCmd:
                    break;

            }

        }


    };
}
