package tw.com.asus.asusservice;


        import android.os.Environment;

        import java.io.BufferedReader;

        import java.io.File;
        import java.io.FileNotFoundException;
        import java.nio.charset.StandardCharsets;
        import java.io.FileInputStream;
        import java.io.IOException;
        import java.io.InputStreamReader;
        import java.util.ArrayList;
        import java.util.HashMap;
        import java.util.regex.Matcher;
        import java.util.regex.Pattern;



/**
 * abstract methods
 * protected abstract I readInstanceInput(String inputLine);
 * protected abstract O readInstanceOutput(String outputLine);
 *
 *
 * @author Alex Chuang
 */
public abstract class AbstractGoldAnswerCacher<I, O> {
    //Pattern.compile("^\\s*$");
    //private static final Pattern BLOCKS_PATTERN =Pattern.compile("^\\s*$", Pattern.DOTALL);
    //private static final Pattern BLOCKS_PATTERN = Pattern.compile("((//)|(/\\*+)|((^\\s)*\\*)|((^\\s)*\\*+/))+",
    //		Pattern.MULTILINE + Pattern.DOTALL);
    private static final Pattern BLOCKS_PATTERN= Pattern.compile("[^\\s]", Pattern.DOTALL);
    private static final Pattern BLOCKS_ELEMENT = Pattern.compile("[:\\n\\t\\f\\r\\x0B]", Pattern.DOTALL);
    private static final boolean CHECK_DUPLICATES = false;

    private final String dataPath;
    String appDirName = "CustomerService";
    protected HashMap<I, O> answerMap;

    public AbstractGoldAnswerCacher(String filePath) {
        this.dataPath = filePath;
        checkFileExistence(dataPath);
        File dirFile = new File(Environment.getExternalStorageDirectory(), appDirName);
        File file = new File(dirFile,dataPath);
        loadData(file);
    }

    public ArrayList<String> splitByEmptyLines(String string) {
        ArrayList<String> matchList = new ArrayList<String>(100);
        Matcher matcher = BLOCKS_PATTERN.matcher(string);
        while (matcher.find()) {
            String group = matcher.group().trim();
            matchList.add(group);

        }
        return matchList;
    }
    public ArrayList<String> splitByLines(String string) {
        ArrayList<String> matchList = new ArrayList<String>(100);
        String lines[] = string.split("\n");
        String temp = "";
        for (int i = 0; i <lines.length; i++){
            if (lines[i].isEmpty()){
                matchList.add(temp);
                temp = "";
            }
            else
                temp += lines[i] + "\n";

            if (lines.length==i+1)
                matchList.add(temp);
        }
        return matchList;
    }


    /**@param */
    protected void loadData(File dataPath) {

        String dataString = read(dataPath);
        ArrayList<String> blocks = splitByEmptyLines(dataString);
        answerMap = new HashMap<I, O>(blocks.size() + blocks.size() / 2);
        for (String block : blocks) {
            block = block.trim();
            if (block.isEmpty())
                continue;
            String[] twoLines = block.split("\n");
            if (twoLines.length != 2){
                throw new RuntimeException("The data file is malformed.");
            }
            I input = readInstanceInput(twoLines[0]);
            O answer = readInstanceOutput(twoLines[1]);

            if (CHECK_DUPLICATES){
                O duplicate = answerMap.get(input);
                if (duplicate != null && answer.equals(duplicate) == false) {
                    throw new RuntimeException("\nwarning: the data already contains an instance with the same key (" + input + ") "
                            + "but different annotated gold answers \n(previous answer : " + duplicate + "; this answer: " + answer +
                            ").\nCheck the file " + dataPath + " and remove all wrong cases.");
                }
            }
            answerMap.put(input, answer);
        }
    }

    protected abstract I readInstanceInput(String inputLine);
    protected abstract O readInstanceOutput(String outputLine);


    protected String read(File dataPath){
        try {
            BufferedReader input =
                    new BufferedReader(new InputStreamReader(
                            new FileInputStream(dataPath),"UTF-8"));
          //  BufferedReader reader = Files.newBufferedReader(Paths.get(dataPath), StandardCharsets.UTF_8);
            StringBuilder builder = new StringBuilder(2000);
            String line = null;
            while ((line = input.readLine()) != null) {
                builder.append(line + "\n");
            }
            input.close();
            return builder.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void checkFileExistence(String filePath) {
        File dirFile = new File(Environment.getExternalStorageDirectory(), appDirName);
        File file = new File(dirFile,filePath);
        if (file.exists() == false || file.isFile() == false){
            try {
                throw new FileNotFoundException("The data file does not exist.");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public int size(){
        return answerMap.size();
    }

    public O lookup(I input){
        return answerMap.get(input);
    }


    public static class StringGoldAnswerCacher extends AbstractGoldAnswerCacher<String, String>{

        /**
         * @param filePath
         */
        public StringGoldAnswerCacher(String filePath) {
            super(filePath);

        }

        @Override
        protected String readInstanceInput(String inputLine) {
            return inputLine.trim();
        }

        @Override
        protected String readInstanceOutput(String outputLine) {
            return outputLine.trim();
        }


    }

    @Override
    public String toString() {
        return "PerfectPerformanceDataCacher [dataPath=" + dataPath + "]";
    }




}
