package tw.com.asus.asusservice;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;

import org.json.simple.JSONObject;

import tw.com.asus.asusservice.AbstractGoldAnswerCacher;


public class AnswerCacher extends AbstractGoldAnswerCacher<JSONObject, String> {

    public AnswerCacher(String filePath) {
        super(filePath);
    }

    @Override
    protected JSONObject readInstanceInput(String inputLine) {

        //ArrayList<String> element = splitByLines(inputLine);

//		String[] Output = null;
        String[] AfterSplit = inputLine.split(" ");
        String[]  Split=null;
        JSONObject sadf = new JSONObject();
        int index=0;
        ArrayList<String> inputList = new ArrayList<String>(AfterSplit.length);
        for (int i = 0; i <AfterSplit.length; i++){
            Split = AfterSplit[i].split(":");
            sadf.put(Split[0], Split[1]);
//		sadf.add(Split[0]);
//		sadf.add(Split[1]);
        }
        // HashMap<String, String> wq;
        // A=如何 B還原 C=Desktop D=windows7

        return sadf;
    }

    @Override
    protected String readInstanceOutput(String outputLine) {
        return null;
    }

    protected void loadData(File dataPath) {
        String dataString = read(dataPath);
        ArrayList<String> blocks = splitByLines(dataString);
        answerMap = new HashMap<JSONObject, String>(blocks.size() + blocks.size() / 2);
        for (String block : blocks) {
            block = block.trim();
            if (block.isEmpty())
                continue;
            String[] manyLines = block.split("\n");
            JSONObject input = readInstanceInput(manyLines[0]);
            StringBuilder answerBuilder = new StringBuilder();
            for (int i = 1; i < manyLines.length; i++) {
                answerBuilder.append(manyLines[i] + "\n");
            }
            answerMap.put(input, answerBuilder.toString());
        }
    }


    public static void main(String[] args) {

        final String filePath = "resources\\enParticularDatatemp.txt";
        AnswerCacher cacher = new AnswerCacher(filePath);

        JSONObject sadf = new JSONObject();
        sadf.put("Howto", "如何");
//		sadf.put("HowtoUseApplicationObject", "USBFlashback");
//		sadf.put("HowtoUseApplicationValue", "使用");
//		 Product:ZD100 HowtoUseAccessorySystemObject:HD100 HowtoUseAccessorySystemValue:連接方法
        //	sadf.put("AbnormalAccessorySystemCondition", "在5Ghz無線模式下欲透過TravelairAC連接至網際網路");
        //Howto:我想知道  AbnormalAccessorySystemObject:WirelessStorage AbnormalAccessorySystemValue:找不到路由器的訊號  AbnormalAccessorySystemCondition:在 5Ghz無線模式下欲透過 TravelairAC連接至網際網路
//		JSONObject sadf = new JSONObject();
//		sadf.put("Howto", "我想知道");
//		sadf.put("Product","AllinOnePC");
        sadf.put("SystemObject", "系統");
        sadf.put("HowtoUpgradeSystemValue", "還原");
        String result = cacher.lookup(sadf);

        System.out.print(result);

    }

}
